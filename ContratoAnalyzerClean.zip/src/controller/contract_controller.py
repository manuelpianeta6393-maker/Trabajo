from src.model.contrato import Contrato
from src.model.analizador import AnalizadorContrato

class ContractController:
    def __init__(self, vista):
        self.vista = vista
        self.analizador = AnalizadorContrato()

    def ejecutar(self):
        texto = self.vista.pedir_texto_contrato()
        contrato = Contrato(texto)
        contrato_analizado = self.analizador.analizar(contrato)
        self.vista.mostrar_reporte(contrato_analizado)
