from src.view.console_view import ConsoleView
from src.controller.contract_controller import ContractController

def main():
    vista = ConsoleView()
    controlador = ContractController(vista)
    controlador.ejecutar()

if __name__ == "__main__":
    main()
