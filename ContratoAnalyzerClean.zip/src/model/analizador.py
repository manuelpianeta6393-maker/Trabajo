from .reglas import ReglaPenalidad, ReglaRenovacionAutomatica

class AnalizadorContrato:
    def __init__(self):
        self._reglas = [
            ReglaPenalidad(),
            ReglaRenovacionAutomatica()
        ]

    def analizar(self, contrato):
        for c in contrato.clausulas:
            for r in self._reglas:
                r.evaluar(c)
        return contrato
