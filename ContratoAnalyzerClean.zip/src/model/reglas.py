from abc import ABC, abstractmethod

class ReglaAnalisis(ABC):
    @abstractmethod
    def evaluar(self, clausula):
        pass

class ReglaPenalidad(ReglaAnalisis):
    def evaluar(self, clausula):
        t = clausula.texto.lower()
        if "multa" in t or "penalidad" in t or "sanción" in t:
            clausula.nivel_riesgo = "ALTO"

class ReglaRenovacionAutomatica(ReglaAnalisis):
    def evaluar(self, clausula):
        t = clausula.texto.lower()
        if "renovación automática" in t or "se renovará automáticamente" in t:
            clausula.nivel_riesgo = "MEDIO"
