from .clausula import Clausula

class Contrato:
    def __init__(self, texto_completo: str):
        self._texto = texto_completo
        self._clausulas = []
        self._dividir_en_clausulas()

    def _dividir_en_clausulas(self):
        partes = self._texto.split(".")
        for p in partes:
            p = p.strip()
            if p:
                self._clausulas.append(Clausula(p))

    @property
    def clausulas(self):
        return self._clausulas
