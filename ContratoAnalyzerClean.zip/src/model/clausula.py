class Clausula:
    def __init__(self, texto: str):
        self._texto = texto
        self._nivel_riesgo = "DESCONOCIDO"

    @property
    def texto(self):
        return self._texto

    @property
    def nivel_riesgo(self):
        return self._nivel_riesgo

    @nivel_riesgo.setter
    def nivel_riesgo(self, valor):
        self._nivel_riesgo = valor
