from rich.console import Console
from rich.table import Table

console = Console()

class ConsoleView:
    def pedir_texto_contrato(self):
        console.print("[bold green]Pegue el texto del contrato y presione ENTER:[/bold green]")
        return input("> ")

    def mostrar_reporte(self, contrato):
        tabla = Table(title="Análisis del contrato")
        tabla.add_column("N°")
        tabla.add_column("Cláusula")
        tabla.add_column("Riesgo")

        for i, c in enumerate(contrato.clausulas, start=1):
            tabla.add_row(str(i), c.texto, c.nivel_riesgo)

        console.print(tabla)
